import pandas as pd
from datetime import datetime  # Corrected import
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

# Check CUDA availability
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")
if device == "cpu":
    print("Warning: CUDA is not available. Running on CPU, which will be slower.")

# Define system prompt
system_prompt = "You are a dog care expert. Answer each question in one concise sentence about the specific topic asked, such as diet, training, or health. Do not ask follow-up questions or provide lists."

# Define the 15 test questions
test_questions = [
    "How should I train a Pudelpointer?",
    "How do I train an Australian Shepherd to stop herding children?",
    "What’s the best way to train a Giant Schnauzer?",
    "How should I socialize a Dutch Shepherd puppy?",
    "What’s the best diet for a Labrador Retriever?",
    "How much should I feed a Pudelpointer?",
    "What should I feed an Australian Kelpie puppy?",
    "Are supplements necessary for a Spanish Water Dog?",
    "How do I groom a Labrador Retriever?",
    "How should I care for a Curly-Coated Retriever’s coat?",
    "How often should I clean a Malshi’s ears?",
    "What health issues should I watch for in a Dutch Shepherd?",
    "How do I manage hip dysplasia in an Australian Shepherd?",
    "What causes seizures in a Pudelpointer?",
    "Why does my Mudi bark so much?"
]

# Ground truth from your dataset (for comparison)
ground_truth = [
    "Use active sessions with positive reinforcement; they thrive in agility.",
    "Redirect herding with early socialization and exercise.",
    "Use positive reinforcement and early socialization to overcome territoriality.",
    "Start socializing immediately with consistent exposure to new situations.",
    "Feed high-quality large-breed adult food meeting AAFCO standards twice daily.",
    "Follow AAFCO guidelines based on weight, 90% food/10% treats, consult vet.",
    "Feed AAFCO-approved puppy food, 3-4 meals daily.",
    "Not needed with AAFCO food, but omega-3s or joint supplements may help if vet-approved.",
    "Brush 2-3 times weekly, bathe occasionally, dry after swimming.",
    "Avoid brushing; bathe rarely, air-dry, rake during shedding.",
    "Clean regularly with vet-recommended cleaner, frequency per vet.",
    "Watch for hip/elbow dysplasia, PRA, bloat, DM, and von Willebrand disease.",
    "Manage with joint supplements, medications, or surgery if severe.",
    "Primary epilepsy causes seizures, onset 1-4 years.",
    "Mudik bark to alert or due to boredom; they’re naturally vocal."
]

# Load the fine-tuned model and tokenizer
model_path = "./fine_tuned_model_dogcare"
try:
    print(f"Loading model from {model_path}...")
    quantization_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.bfloat16
    )
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        quantization_config=quantization_config,
        device_map="auto",
        torch_dtype=torch.bfloat16
    )
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model.eval()  # Set model to evaluation mode
    print("Model and tokenizer loaded successfully.")
except Exception as e:
    print(f"Error loading model or tokenizer: {e}")
    exit(1)

# Ensure the tokenizer has a padding token
if tokenizer.pad_token is None:
    print("Setting padding token to EOS token.")
    tokenizer.pad_token = tokenizer.eos_token

# Function to test model responses
def test_model(question):
    formatted_prompt = f"{system_prompt}\n\nQuestion: {question}\nAnswer:"
    inputs = tokenizer(formatted_prompt, return_tensors="pt").to(device)
    outputs = model.generate(
        **inputs,
        max_new_tokens=75,  # Increased to allow complete sentences
        num_return_sequences=1,
        do_sample=False,  # Deterministic generation
        use_cache=True,
        temperature=None,  # Explicitly unset to avoid warnings
        top_p=None  # Explicitly unset to avoid warnings
    )
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    # Extract the answer part after "Answer:" and take the first sentence
    if "Answer:" in response:
        response = response.split("Answer:")[-1].strip()
        response = response.split(".")[0].strip()
        if not response:  # If empty after splitting, use the full response
            response = response.split("\n")[0].strip()
    return response

# Run tests and compare with ground truth
print("\n🔍 **Testing Fine-Tuned Model on Dog Care Questions:**\n")
for i, (question, truth) in enumerate(zip(test_questions, ground_truth)):
    answer = test_model(question)
    print(f"🤖 Question {i+1}: {question}")
    print(f"📝 AI Response: {answer}")
    print(f"✅ Ground Truth: {truth}")
    print(f"{'-'*50}\n")

# Save results to CSV for comparison
data = {
    "Question": test_questions,
    "Fine-Tuned Response": [test_model(q) for q in test_questions],
    "Ground Truth": ground_truth
}
df = pd.DataFrame(data)
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
df.to_csv(f"fine_tuned_results_1b_{timestamp}.csv", index=False)
print(f"Testing complete. Results saved to fine_tuned_results_1b_{timestamp}.csv")