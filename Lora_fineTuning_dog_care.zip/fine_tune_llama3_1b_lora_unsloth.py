import torch
from datasets import load_dataset
from transformers import TrainingArguments, Trainer, DataCollatorForSeq2Seq, BitsAndBytesConfig, AutoModelForCausalLM, AutoTokenizer
from peft import LoraConfig, get_peft_model

# Check CUDA availability
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")
if device == "cpu":
    print("Warning: CUDA is not available. Running on CPU, which will be slower.")

# Define system prompt
system_prompt = "You are a dog care expert. Answer each question in one concise sentence about the specific topic asked, such as diet, training, or health. Do not ask follow-up questions or provide lists."

# Load dataset
try:
    print("Loading dataset...")
    dataset = load_dataset("json", data_files={"train": "train_data.jsonl", "validation": "val_data.jsonl"})
    print(f"Dataset loaded. Train size: {len(dataset['train'])}, Validation size: {len(dataset['validation'])}")
except Exception as e:
    print(f"Error loading dataset: {e}")
    exit(1)

# Verify dataset structure
if "prompt" not in dataset["train"].column_names or "response" not in dataset["train"].column_names:
    raise ValueError("Dataset must have 'prompt' and 'response' columns.")

# Load tokenizer and model
model_name = "unsloth/Llama-3.2-1B-Instruct"
max_seq_length = 128

try:
    print(f"Loading model from {model_name}...")
    quantization_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.bfloat16
    )
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        quantization_config=quantization_config,
        device_map="auto",
        torch_dtype=torch.bfloat16
    )
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    print("Model and tokenizer loaded successfully.")
except Exception as e:
    print(f"Error loading model or tokenizer: {e}")
    exit(1)

# Ensure the tokenizer has a padding token
if tokenizer.pad_token is None:
    print("Setting padding token to EOS token.")
    tokenizer.pad_token = tokenizer.eos_token

# Preprocess dataset
def preprocess_function(examples):
    inputs = [f"{system_prompt}\n\nQuestion: {q}\nAnswer:" for q in examples["prompt"]]
    targets = [f"{a} {tokenizer.eos_token}" for a in examples["response"]]

    model_inputs = tokenizer(
        inputs,
        padding="max_length",
        truncation=True,
        max_length=max_seq_length
    )

    labels = tokenizer(
        targets,
        padding="max_length",
        truncation=True,
        max_length=max_seq_length
    )

    model_inputs["labels"] = labels["input_ids"]
    return model_inputs

try:
    print("Tokenizing dataset...")
    print("Tokenizing training dataset...")
    train_dataset = dataset["train"].map(
        preprocess_function,
        batched=True,
        remove_columns=["prompt", "response"]
    )
    print(f"Training dataset tokenized. Size: {len(train_dataset)}")

    print("Tokenizing validation dataset...")
    val_dataset = dataset["validation"].map(
        preprocess_function,
        batched=True,
        remove_columns=["prompt", "response"]
    )
    print(f"Validation dataset tokenized. Size: {len(val_dataset)}")

    tokenized_datasets = {"train": train_dataset, "validation": val_dataset}
    print("Dataset tokenized successfully.")
except Exception as e:
    print(f"Error tokenizing dataset: {e}")
    exit(1)

# LoRA configuration
try:
    print("Configuring LoRA...")
    lora_config = LoraConfig(
        r=16,
        lora_alpha=32,
        target_modules=["q_proj", "v_proj"],
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM"
    )
    model = get_peft_model(model, lora_config)

    trainable_params = 0
    total_params = 0
    for name, param in model.named_parameters():
        total_params += param.numel()
        if param.requires_grad:
            trainable_params += param.numel()
            print(f"Trainable parameter: {name}, requires_grad: {param.requires_grad}")
    print(f"Total parameters: {total_params}, Trainable parameters: {trainable_params}, Percentage trainable: {(trainable_params / total_params) * 100:.2f}%")
    
    print("LoRA configured successfully.")
except Exception as e:
    print(f"Error configuring LoRA: {e}")
    exit(1)

# Set up data collator
data_collator = DataCollatorForSeq2Seq(tokenizer, model=model, padding=True)

# Training arguments
training_args = TrainingArguments(
    output_dir="./fine_tuned_model_dogcare",
    per_device_train_batch_size=4,
    gradient_accumulation_steps=4,
    eval_strategy="epoch",
    save_strategy="epoch",
    logging_dir="./logs",
    num_train_epochs=10,  # Revert to original 10 epochs
    weight_decay=0.01,
    logging_steps=20,
    fp16=False,
    bf16=True,
    optim="adamw_torch",
    lr_scheduler_type="cosine",
    learning_rate=5e-6,  # Revert to original learning rate
    warmup_ratio=0.2,
    remove_unused_columns=False,
    max_grad_norm=0.3,
    seed=3407
)

# Trainer setup
try:
    print("Setting up trainer...")
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_datasets["train"],
        eval_dataset=tokenized_datasets["validation"],
        data_collator=data_collator,
        tokenizer=tokenizer
    )
    print("Trainer set up successfully.")
except Exception as e:
    print(f"Error setting up trainer: {e}")
    exit(1)

# Start fine-tuning
try:
    print("Starting fine-tuning...")
    trainer.train()
    print("Fine-tuning completed successfully.")
except Exception as e:
    print(f"Error during fine-tuning: {e}")
    exit(1)

# Save fine-tuned model
try:
    print("Saving fine-tuned model...")
    model.save_pretrained("./fine_tuned_model_dogcare")
    tokenizer.save_pretrained("./fine_tuned_model_dogcare")
    print("LoRA fine-tuning complete. Model saved to ./fine_tuned_model_dogcare")
except Exception as e:
    print(f"Error saving model: {e}")
    exit(1)