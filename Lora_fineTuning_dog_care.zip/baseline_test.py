import pandas as pd
from datetime import datetime
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

# Check CUDA availability
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")
if device == "cpu":
    print("Warning: CUDA is not available. Running on CPU, which will be slower.")

# Define system prompt
system_prompt = "You are a dog care expert. Answer each question in one concise sentence about the specific topic asked, such as diet, training, or health. Do not ask follow-up questions or provide lists."

# Define the 15 test questions
questions = [
    "How should I train a Pudelpointer?",
    "How do I train an Australian Shepherd to stop herding children?",
    "What’s the best way to train a Giant Schnauzer?",
    "How should I socialize a Dutch Shepherd puppy?",
    "What’s the best diet for a Labrador Retriever?",
    "How much should I feed a Pudelpointer?",
    "What should I feed an Australian Kelpie puppy?",
    "Are supplements necessary for a Spanish Water Dog?",
    "How do I groom a Labrador Retriever?",
    "How should I care for a Curly-Coated Retriever’s coat?",
    "How often should I clean a Malshi’s ears?",
    "What health issues should I watch for in a Dutch Shepherd?",
    "How do I manage hip dysplasia in an Australian Shepherd?",
    "What causes seizures in a Pudelpointer?",
    "Why does my Mudi bark so much?"
]

# Ground truth from your dataset (shortened to one line for consistency)
ground_truth = [
    "Use active sessions with positive reinforcement; they thrive in agility.",
    "Redirect herding with early socialization and exercise.",
    "Use positive reinforcement and early socialization to overcome territoriality.",
    "Start socializing immediately with consistent exposure to new situations.",
    "Feed high-quality large-breed adult food meeting AAFCO standards twice daily.",
    "Follow AAFCO guidelines based on weight, 90% food/10% treats, consult vet.",
    "Feed AAFCO-approved puppy food, 3-4 meals daily.",
    "Not needed with AAFCO food, but omega-3s or joint supplements may help if vet-approved.",
    "Brush 2-3 times weekly, bathe occasionally, dry after swimming.",
    "Avoid brushing; bathe rarely, air-dry, rake during shedding.",
    "Clean regularly with vet-recommended cleaner, frequency per vet.",
    "Watch for hip/elbow dysplasia, PRA, bloat, DM, and von Willebrand disease.",
    "Manage with joint supplements, medications, or surgery if severe.",
    "Primary epilepsy causes seizures, onset 1-4 years.",
    "Mudik bark to alert or due to boredom; they’re naturally vocal."
]

# Load the baseline model and tokenizer
model_name = "unsloth/Llama-3.2-1B-Instruct"
max_seq_length = 128  # Match baseline max_length

try:
    print(f"Loading model from {model_name}...")
    # Configure 4-bit quantization with BitsAndBytesConfig
    quantization_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.float16  # Match model dtype for faster inference
    )
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        quantization_config=quantization_config,
        device_map="auto",
        torch_dtype=torch.float16  # Use FP16 for computation
    )
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model.eval()  # Set model to evaluation mode
    print("Model and tokenizer loaded successfully.")
except Exception as e:
    print(f"Error loading model or tokenizer: {e}")
    exit(1)

# Ensure the tokenizer has a padding token
if tokenizer.pad_token is None:
    print("Setting padding token to EOS token.")
    tokenizer.pad_token = tokenizer.eos_token

# Run baseline test with system prompt
responses = []
for question in questions:
    try:
        print(f"Generating response for question: {question}")
        # Format the prompt with system instruction
        formatted_prompt = f"{system_prompt}\n\nQuestion: {question}\nAnswer:"
        inputs = tokenizer(
            formatted_prompt,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=max_seq_length
        )
        # Explicitly move inputs to the GPU
        inputs = {k: v.to(device) for k, v in inputs.items()}
        outputs = model.generate(
            **inputs,
            max_new_tokens=75,  # Increased to allow complete sentences
            num_return_sequences=1,
            do_sample=False,  # Deterministic generation
            use_cache=True,
            temperature=None,  # Explicitly unset to avoid warnings
            top_p=None  # Explicitly unset to avoid warnings
        )
        response = tokenizer.decode(outputs[0], skip_special_tokens=True)
        # Extract the answer part after "Answer:" and take the first sentence
        if "Answer:" in response:
            response = response.split("Answer:")[-1].strip()
            # Take only the first sentence (up to the first period or newline)
            response = response.split(".")[0].strip()
            if not response:  # If empty after splitting, use the full response
                response = response.split("\n")[0].strip()
        else:
            response = response.strip()
        print(f"Generated response: {response}")
    except Exception as e:
        print(f"Error generating response for question {question}: {e}")
        response = "Error generating response"

    responses.append(response)

# Create a DataFrame to store results
data = {
    "Question": questions,
    "Baseline Response": responses,
    "Ground Truth": ground_truth
}
df = pd.DataFrame(data)

# Save to CSV with timestamp
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
df.to_csv(f"baseline_results_1b_{timestamp}.csv", index=False)
print(f"Baseline testing complete. Results saved to baseline_results_1b_{timestamp}.csv")